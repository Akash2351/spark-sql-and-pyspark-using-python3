print("importing strings in extras")
import strings

name = "Kim"